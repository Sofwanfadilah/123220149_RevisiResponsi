/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package responsi;

import Controller.loginController;
import model.userModel;
import view.LoginPageView;

/**
 *
 * @author sofwan fadilah
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException {
        userModel model = new userModel();
        LoginPageView view = new LoginPageView();
        loginController controller = new loginController(model,view);
        // TODO code application logic here
    }
    
}

